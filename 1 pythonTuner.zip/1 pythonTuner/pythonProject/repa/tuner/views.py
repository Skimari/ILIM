from django.shortcuts import render

def tuner(request):
    return render(request,'tuner/tuner.html')
