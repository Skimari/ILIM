from django.db import models

class Order(models.Model):
    FAILURE_REASONS = (
        ('start', 'Выберите причину обращения ↓'),
        ('screen', 'Ремонт и обслуживание'),
        ('battery', 'Настройка и кастомизация'),
        ('software', 'Консультации и обучение'),
    )
    failure_reason = models.CharField(max_length=50, choices=FAILURE_REASONS,default='screen')
    number = models.CharField('Номер телефона', max_length=15)
    soc = models.CharField('Социальная сеть', max_length=250)
    full_text = models.TextField('Описание заказа')
    author = models.ForeignKey( 'auth.User',on_delete=models.CASCADE, null=True)
    #image_broke = models.ImageField('Фото поломки',upload_to='images')

    def __str__(self):
        return self.number

    def get_absolute_url(self):
        return f'/orders/{self.id}'

    class Meta:
        verbose_name='Заказ'
        verbose_name_plural = 'Заказы'
