from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', views.index, name='home'),
    path('about', views.about, name='about'),
    path('register', views.register_request, name='register'),
    path('login_auth', views.login_request, name='login_auth'),
    path('kabinet', views.kabinet, name='kabinet'),
    path('logout', auth_views.LogoutView.as_view(), name='logout'),
    path('order', views.order, name='order'),
]