from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import NewUserForm, OrderForm
from django.contrib.auth import login
from django.contrib import messages
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .models import Order

def index(request):
    data= {
        'title': 'Fixer: ремонт гитар',
        'values': ['Some','Hello','123'],
        'obj':{'car':'BMW','age':18,'hobby':'Football'}
    }
    return render(request,'main/index.html',data)

def about(request):
    return render(request,'main/about.html')

def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            #login(request, user)
            messages.success(request, "Registration successful." )
            return redirect("login_auth")
        messages.error(request, "Unsuccessful registration. Invalid information.")

    form = NewUserForm()

    data = {
        'form': form
    }

    return render(request, "main/register.html", data)

def login_request(request):
	if request.method == "POST":
		form = AuthenticationForm(request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				login(request, user)
				messages.info(request, f"You are now logged in as {username}.")
				return redirect("home")
			else:
				messages.error(request,"Invalid username or password.")
		else:
			messages.error(request,"Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request, template_name="main/login.html", context={"login_form":form})

def kabinet(request):
    orders=Order.objects.all()
    return render(request, 'main/kabinet.html',{'orders':orders})

def order(request):
    error=''
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.author = request.user
            print(request.user)
            new_post.save()
            return redirect('kabinet')
        else:
            error = 'Форма неверно заполнена'

    form = OrderForm()

    data = {
        'form': form,
        'error': error
    }

    return render(request, 'main/order.html',data)

