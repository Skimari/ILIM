from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.forms import TextInput, EmailInput, PasswordInput, ModelForm, Textarea, ImageField
from django.contrib.auth.models import User
from .models import Order


# Create your forms here.

class NewUserForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password1']


    def save(self, commit=True):
        user = super(NewUserForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user

class OrderForm(ModelForm):
    FAILURE_REASONS = (
        ('start', 'Выберите причину обращения ↓'),
        ('screen', 'Ремонт и обслуживание'),
        ('battery', 'Настройка и кастомизация'),
        ('software', 'Консультации и обучение'),
    )
    failure_reason = forms.ChoiceField(choices=FAILURE_REASONS, widget=forms.Select(attrs={
        'class': 'form-control',
    }))
    class Meta:
        model = Order
        exclude = ["author"]
        fields = ['failure_reason', 'number', 'soc', 'full_text']

        widgets = {
            "number": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Номер телефона'
            }),
            "soc": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ссылка на любую соц. сеть'
            }),
            "full_text": Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Текст заказа'
            })
        }